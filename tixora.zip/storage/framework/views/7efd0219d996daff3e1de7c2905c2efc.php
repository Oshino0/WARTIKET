<?php $__env->startSection('title', 'Pesanan saya'); ?>
<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-bold">Pesanan saya</h1>

  <?php if($orders->isEmpty()): ?>
    <div class="mt-6 rounded-2xl border border-dashed border-violet-200 p-10 text-center">
      <p class="text-gray-500">Kamu belum punya pesanan.</p>
      <a href="<?php echo e(route('explore')); ?>" class="btn btn-primary mt-4">Cari tiket</a>
    </div>
  <?php else: ?>
    <ul class="mt-6 space-y-3">
      <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
          <a href="<?php echo e(route('orders.show', $order->order_number)); ?>" class="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-violet-100 p-4 hover:border-brand-accent">
            <div>
              <p class="font-semibold"><?php echo e($order->order_number); ?></p>
              <p class="text-sm text-gray-500">
                <?php echo e($order->created_at->translatedFormat('d M Y, H:i')); ?> • <?php echo e($order->items->sum('quantity')); ?> tiket
                • <?php echo e($order->items->pluck('product_name_snapshot')->unique()->implode(', ')); ?>

              </p>
            </div>
            <div class="flex items-center gap-4">
              <span class="font-bold"><?php echo e(\App\Support\Money::rp($order->total)); ?></span>
              <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['order' => $order]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['order' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
            </div>
          </a>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <div class="mt-6"><?php echo e($orders->links()); ?></div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\tixora\tixora\resources\views\customer\orders\index.blade.php ENDPATH**/ ?>