<?php $__env->startSection('title', 'Pesanan diterima'); ?>
<?php $__env->startSection('content'); ?>
  <div class="mx-auto max-w-2xl">
    <div class="rounded-2xl border border-violet-100 bg-white p-6 sm:p-8">
      <p class="text-sm font-semibold uppercase tracking-wide text-brand">Pesanan diterima</p>
      <h1 class="mt-2 text-2xl font-extrabold">Menunggu verifikasi admin</h1>
      <?php if($order->status === \App\Models\Order::SENT): ?>
        <p class="mt-3 text-gray-600">
          Pesananmu sudah dikonfirmasi. E-tiket telah dikirim ke <strong><?php echo e($order->buyer_email); ?></strong>.
        </p>
      <?php elseif($order->status === \App\Models\Order::REJECTED): ?>
        <p class="mt-3 text-gray-600">Pesanan ini tidak dapat dikonfirmasi. Hubungi panitia acara jika membutuhkan bantuan.</p>
      <?php else: ?>
        <p class="mt-3 text-gray-600">
          Kami akan mengirim e-tiket ke <strong><?php echo e($order->buyer_email); ?></strong> setelah pesanan dikonfirmasi.
        </p>
      <?php endif; ?>
      <p class="mt-2 text-sm text-gray-500">Simpan nomor pesanan ini untuk referensi.</p>
      <p class="mt-4 rounded-xl bg-brand-surface p-4 text-lg font-bold text-brand"><?php echo e($order->order_number); ?></p>

      <div class="mt-6 divide-y divide-violet-100 rounded-xl border border-violet-100">
        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="flex justify-between gap-4 p-4 text-sm">
            <div>
              <p class="font-semibold"><?php echo e($item->product_name_snapshot); ?></p>
              <p class="text-gray-500"><?php echo e($item->ticket_type_name_snapshot); ?> × <?php echo e($item->quantity); ?></p>
            </div>
            <p class="whitespace-nowrap font-semibold"><?php echo e(\App\Support\Money::rp($item->line_total)); ?></p>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="flex justify-between gap-4 p-4 font-bold">
          <span>Total</span>
          <span><?php echo e(\App\Support\Money::rp($order->total)); ?></span>
        </div>
      </div>

      <a href="<?php echo e(route('explore')); ?>" class="btn btn-primary mt-6">Kembali jelajahi acara</a>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\tixora\tixora\resources\views/customer/checkout-confirmation.blade.php ENDPATH**/ ?>