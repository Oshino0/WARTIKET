<?php $__env->startSection('title', 'Produk'); ?>
<?php $__env->startSection('content'); ?>
  <div class="flex flex-wrap items-center justify-between gap-3">
    <h1 class="text-2xl font-bold">Produk tiket</h1>
    <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary">Tambah produk</a>
  </div>

  <form method="GET" class="mt-6 flex flex-wrap gap-3" role="search">
    <label for="q" class="sr-only">Cari produk</label>
    <input id="q" name="q" value="<?php echo e($search); ?>" placeholder="Cari nama produk" class="input max-w-xs">
    <label for="status" class="sr-only">Status</label>
    <select id="status" name="status" class="input max-w-[14rem]">
      <option value="">Semua status</option>
      <?php $__currentLoopData = \App\Models\Product::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($value); ?>" <?php if(request('status') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button class="btn btn-ghost">Filter</button>
  </form>

  <div class="mt-4 overflow-x-auto rounded-2xl border border-violet-100 bg-white">
    <table class="w-full min-w-[40rem]">
      <thead class="bg-brand-surface"><tr><th class="th">Produk</th><th class="th">Kategori</th><th class="th">Jadwal</th><th class="th text-right">Tipe tiket</th><th class="th">Status</th><th class="th"></th></tr></thead>
      <tbody class="divide-y divide-violet-100">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td class="td font-medium"><?php echo e($product->name); ?><?php if($product->is_featured): ?> <span class="ml-1 rounded bg-brand-surface px-1.5 py-0.5 text-xs text-brand">Populer</span><?php endif; ?></td>
            <td class="td"><?php echo e($product->category->name); ?></td>
            <td class="td text-gray-500"><?php echo e($product->start_at?->translatedFormat('d M Y, H:i') ?? '–'); ?></td>
            <td class="td text-right"><?php echo e($product->ticket_types_count); ?></td>
            <td class="td"><?php echo e(\App\Models\Product::STATUSES[$product->status] ?? $product->status); ?></td>
            <td class="td">
              <div class="flex justify-end gap-2">
                <a href="<?php echo e(route('admin.products.edit', $product)); ?>" class="btn btn-ghost !py-1">Kelola</a>
                <form action="<?php echo e(route('admin.products.destroy', $product)); ?>" method="POST" onsubmit="return confirm('Hapus produk <?php echo e(addslashes($product->name)); ?>? Riwayat pesanan tetap tersimpan.')">
                  <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-danger !py-1">Hapus</button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td class="td text-center text-gray-500" colspan="6">Belum ada produk.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <div class="mt-4"><?php echo e($products->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\tixora\tixora\resources\views\admin\products\index.blade.php ENDPATH**/ ?>