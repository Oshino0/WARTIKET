<?php $__env->startSection('title', 'Banner'); ?>
<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-bold">Banner homepage</h1>

  <?php echo $__env->make('admin.banners._form', ['banner' => null, 'submitLabel' => 'Tambah banner'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <div class="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
    <?php $__empty_1 = true; $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="overflow-hidden rounded-2xl border border-violet-100 bg-white">
        <img src="<?php echo e($banner->image_url); ?>" alt="<?php echo e($banner->title); ?>" class="aspect-[3/1] w-full object-cover <?php echo e($banner->is_active ? '' : 'opacity-40'); ?>" style="object-position: <?php echo e($banner->image_position_x); ?>% <?php echo e($banner->image_position_y); ?>%;">
        <div class="p-4">
          <p class="font-semibold"><?php echo e($banner->title); ?></p>
          <p class="text-xs text-gray-500">Urutan <?php echo e($banner->sort_order); ?> • <?php echo e($banner->is_active ? 'Aktif' : 'Nonaktif'); ?></p>
          <div class="mt-3 flex gap-2">
            <a href="<?php echo e(route('admin.banners.edit', $banner)); ?>" class="btn btn-ghost !py-1">Ubah</a>
            <form action="<?php echo e(route('admin.banners.toggle', $banner)); ?>" method="POST"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
              <button class="btn btn-ghost !py-1"><?php echo e($banner->is_active ? 'Nonaktifkan' : 'Aktifkan'); ?></button></form>
            <form action="<?php echo e(route('admin.banners.destroy', $banner)); ?>" method="POST" onsubmit="return confirm('Hapus banner ini?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
              <button class="btn btn-danger !py-1">Hapus</button></form>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <p class="text-gray-500">Belum ada banner.</p>
    <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\tixora\tixora\resources\views/admin/banners/index.blade.php ENDPATH**/ ?>