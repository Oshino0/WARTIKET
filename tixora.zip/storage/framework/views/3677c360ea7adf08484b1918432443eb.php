<!DOCTYPE html>
<html lang="id">
<head><?php echo $__env->make('layouts.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></head>
<body class="min-h-screen bg-white font-sans text-brand-ink antialiased">
  <a href="#main" class="sr-only rounded bg-white px-3 py-2 focus:not-sr-only focus:absolute focus:left-3 focus:top-3 focus:z-50">Lewati ke konten</a>

  <header class="border-b border-violet-100">
    <div class="mx-auto grid max-w-6xl grid-cols-[1fr_auto] items-center gap-x-4 gap-y-3 px-4 pb-3 pt-6 lg:grid-cols-[minmax(0,1fr)_minmax(18rem,28rem)_minmax(0,1fr)] xl:grid-cols-[minmax(0,1fr)_minmax(20rem,34rem)_minmax(0,1fr)]">
      <div class="flex items-center gap-4">
        <a href="<?php echo e(route('home')); ?>" class="text-xl font-extrabold tracking-tight text-brand">TIXORA</a>
        <nav class="hidden items-center gap-5 text-sm font-semibold lg:flex" aria-label="Utama">
          <a href="<?php echo e(route('explore')); ?>" class="text-gray-700 transition hover:text-brand">Jelajahi</a>
        </nav>
      </div>

      <form action="<?php echo e(route('explore')); ?>" method="GET" role="search"
        class="col-span-2 row-start-2 flex h-11 w-full items-center gap-2 rounded-full border-2 border-violet-300 bg-brand-surface p-1 shadow-sm transition focus-within:border-brand focus-within:ring-4 focus-within:ring-violet-100 lg:col-span-1 lg:col-start-2 lg:row-start-1 lg:justify-self-center">
        <label for="header-q" class="sr-only">Cari tiket</label>
        <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" class="ml-3 h-5 w-5 shrink-0 text-brand">
          <circle cx="11" cy="11" r="7" />
          <path stroke-linecap="round" d="m16 16 4 4" />
        </svg>
        <input id="header-q" type="search" name="q" value="<?php echo e(request('q')); ?>" placeholder="Cari acara, konser, tiket..." class="h-full min-w-0 flex-1 border-0 bg-transparent text-sm outline-none placeholder:text-gray-500 focus:ring-0">
        <button class="btn btn-primary !h-full !rounded-full !px-5">Cari</button>
      </form>

      <?php $cartQuantity = array_sum((array) session('cart', [])); ?>
      <div class="col-start-2 row-start-1 flex items-center justify-self-end gap-3 text-sm font-medium lg:col-start-3">
        <a href="<?php echo e(route('cart.index')); ?>" class="btn btn-ghost !gap-2 !px-3 !py-2" aria-label="Keranjang, <?php echo e($cartQuantity); ?> tiket">
          <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" class="h-5 w-5">
            <path stroke-linecap="round" stroke-linejoin="round" d="M3 3h2l2.2 11.1a2 2 0 0 0 2 1.6h8.9a2 2 0 0 0 2-1.6L22 7H6" />
            <circle cx="10" cy="20" r="1" /><circle cx="18" cy="20" r="1" />
          </svg>
          <span class="hidden sm:inline">Keranjang</span>
          <?php if($cartQuantity > 0): ?>
            <span class="rounded-full bg-brand px-2 py-0.5 text-xs text-white"><?php echo e($cartQuantity); ?></span>
          <?php endif; ?>
        </a>
        <?php if(auth()->guard()->check()): ?>
          <details class="group relative">
            <summary class="flex h-10 w-10 cursor-pointer list-none items-center justify-center rounded-full border border-violet-200 bg-white text-brand transition hover:border-brand hover:bg-brand-surface focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand" aria-label="Menu akun" title="Menu akun">
              <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" class="h-5 w-5">
                <circle cx="12" cy="8" r="3.5" />
                <path stroke-linecap="round" stroke-linejoin="round" d="M5 20a7 7 0 0 1 14 0" />
              </svg>
            </summary>
            <div class="absolute right-0 top-full z-50 mt-2 w-56 rounded-2xl border border-violet-100 bg-white p-2 shadow-xl">
              <p class="truncate px-3 py-2 text-sm font-semibold text-gray-800"><?php echo e(auth()->user()->name); ?></p>
              <?php if(auth()->user()->isCustomer()): ?>
                <a href="<?php echo e(route('orders.index')); ?>" class="block rounded-xl px-3 py-2 text-sm text-gray-700 hover:bg-brand-surface hover:text-brand">Pesanan saya</a>
                <a href="<?php echo e(route('profile.edit')); ?>" class="block rounded-xl px-3 py-2 text-sm text-gray-700 hover:bg-brand-surface hover:text-brand">Profil</a>
              <?php elseif(auth()->user()->isAdmin()): ?>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="block rounded-xl px-3 py-2 text-sm text-gray-700 hover:bg-brand-surface hover:text-brand">Dashboard admin</a>
              <?php else: ?>
                <a href="<?php echo e(route('officer.dashboard')); ?>" class="block rounded-xl px-3 py-2 text-sm text-gray-700 hover:bg-brand-surface hover:text-brand">Dashboard petugas</a>
              <?php endif; ?>
              <form action="<?php echo e(route('logout')); ?>" method="POST" class="mt-1 border-t border-violet-100 pt-1"><?php echo csrf_field(); ?>
                <button class="block w-full rounded-xl px-3 py-2 text-left text-sm font-medium text-red-700 hover:bg-red-50">Keluar</button>
              </form>
            </div>
          </details>
        <?php else: ?>
          <a href="<?php echo e(route('login')); ?>" class="flex h-10 w-10 items-center justify-center rounded-full border border-violet-200 bg-white text-brand transition hover:border-brand hover:bg-brand-surface focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand" aria-label="Masuk" title="Masuk">
            <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" class="h-5 w-5">
              <circle cx="12" cy="8" r="3.5" />
              <path stroke-linecap="round" stroke-linejoin="round" d="M5 20a7 7 0 0 1 14 0" />
            </svg>
          </a>
          <a href="<?php echo e(route('register')); ?>" class="btn btn-primary !h-10 !px-4 !py-0">Daftar</a>
        <?php endif; ?>
      </div>
    </div>
  </header>

  <main id="main" class="mx-auto max-w-6xl px-4 pb-10 pt-6">
    <?php echo $__env->make('layouts.messages', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
  </main>

  <footer class="mt-16 border-t border-violet-100">
    <div class="mx-auto max-w-6xl px-4 py-8 text-sm text-gray-500">TIXORA – tiket konser, olahraga, bioskop, kuliner, seminar, dan wisata.</div>
  </footer>
</body>
</html><?php /**PATH D:\project\tixora\tixora\resources\views\layouts\app.blade.php ENDPATH**/ ?>