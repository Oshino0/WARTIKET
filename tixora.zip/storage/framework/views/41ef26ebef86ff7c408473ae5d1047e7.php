<?php $__env->startSection('title', 'Ubah banner'); ?>
<?php $__env->startSection('content'); ?>
  <div class="max-w-2xl">
    <h1 class="text-2xl font-bold">Ubah banner</h1>
    <p class="mt-1 text-sm text-gray-600">Atur detail, posisi gambar, atau urutan tampil banner.</p>
    <?php echo $__env->make('admin.banners._form', ['banner' => $banner, 'submitLabel' => 'Simpan perubahan'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\tixora\tixora\resources\views/admin/banners/edit.blade.php ENDPATH**/ ?>