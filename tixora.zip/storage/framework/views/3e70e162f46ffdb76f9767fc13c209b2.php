<?php $__env->startSection('title', 'Pesanan'); ?>
<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-bold">Pesanan</h1>

  <form method="GET" class="mt-6 flex flex-wrap gap-3" role="search">
    <label for="q" class="sr-only">Cari pesanan</label>
    <input id="q" name="q" value="<?php echo e($search); ?>" placeholder="Nomor pesanan, nama, atau email" class="input max-w-xs">
    <label for="status" class="sr-only">Status</label>
    <select id="status" name="status" class="input max-w-[14rem]">
      <option value="">Semua status</option>
      <?php $__currentLoopData = \App\Models\Order::LABELS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($value); ?>" <?php if(request('status') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button class="btn btn-ghost">Filter</button>
  </form>

  <div class="mt-4 overflow-x-auto rounded-2xl border border-violet-100 bg-white">
    <table class="w-full min-w-[44rem]">
      <thead class="bg-brand-surface"><tr><th class="th">Pesanan</th><th class="th">Customer</th><th class="th">Tiket</th><th class="th text-right">Total</th><th class="th">Dibuat</th><th class="th">Status</th></tr></thead>
      <tbody class="divide-y divide-violet-100">
        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td class="td font-medium"><?php echo e($order->order_number); ?></td>
            <td class="td"><?php echo e($order->user->name); ?><br><span class="text-xs text-gray-500"><?php echo e($order->user->email); ?></span></td>
            <td class="td"><?php echo e($order->items->sum('quantity')); ?></td>
            <td class="td text-right"><?php echo e(\App\Support\Money::rp($order->total)); ?></td>
            <td class="td text-gray-500"><?php echo e($order->created_at->translatedFormat('d M Y, H:i')); ?></td>
            <td class="td"><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['order' => $order]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['order' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td class="td text-center text-gray-500" colspan="6">Tidak ada pesanan.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <div class="mt-4"><?php echo e($orders->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\tixora\tixora\resources\views\admin\orders\index.blade.php ENDPATH**/ ?>