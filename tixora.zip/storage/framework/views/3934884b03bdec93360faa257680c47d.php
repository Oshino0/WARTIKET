<?php if(session('status')): ?>
  <div role="status" class="mb-6 rounded-xl border border-violet-200 bg-brand-surface px-4 py-3 text-sm text-brand"><?php echo e(session('status')); ?></div>
<?php endif; ?>
<?php $__currentLoopData = ['items', 'order', 'category', 'ticket_type', 'quantity']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php $__errorArgs = [$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div role="alert" class="mb-6 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"><?php echo e($message); ?></div>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\project\tixora\tixora\resources\views\layouts\messages.blade.php ENDPATH**/ ?>