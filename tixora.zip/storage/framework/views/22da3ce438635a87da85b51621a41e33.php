<?php $__env->startSection('title', 'Dashboard petugas'); ?>
<?php $__env->startSection('content'); ?>
  <div class="mx-auto max-w-lg text-center">
    <h1 class="text-2xl font-bold">Halo, <?php echo e(auth()->user()->name); ?></h1>
    <p class="mt-3 text-gray-600">Pemindai QR dan check-in tiket belum tersedia di versi ini. Akun petugasmu sudah aktif dan akan langsung bisa dipakai saat fitur itu dirilis.</p>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\tixora\tixora\resources\views\officer\dashboard.blade.php ENDPATH**/ ?>