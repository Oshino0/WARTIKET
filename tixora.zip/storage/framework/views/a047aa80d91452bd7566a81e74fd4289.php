<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-bold">Dashboard</h1>

  <dl class="mt-6 grid gap-px overflow-hidden rounded-2xl border border-violet-100 bg-violet-100 sm:grid-cols-4 lg:grid-cols-7">
    <?php $__currentLoopData = [
      ['Omzet (dibayar)', \App\Support\Money::rp($stats['revenue'])],
      ['Total pesanan', number_format($stats['orders'], 0, ',', '.')],
      ['Menunggu bayar', number_format($stats['pending'], 0, ',', '.')],
      ['Tiket terjual', number_format($stats['tickets_sold'], 0, ',', '.')],
      ['Tiket dicadangkan', number_format($stats['reserved'], 0, ',', '.')],
      ['Produk aktif', number_format($stats['products'], 0, ',', '.')],
      ['Perlu ditinjau', number_format($stats['review'], 0, ',', '.')],
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="bg-white p-4">
        <dt class="text-xs text-gray-500"><?php echo e($label); ?></dt>
        <dd class="mt-1 text-xl font-bold"><?php echo e($value); ?></dd>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </dl>

  <h2 class="mt-10 text-lg font-bold">Pesanan terbaru</h2>
  <div class="mt-3 overflow-x-auto rounded-2xl border border-violet-100 bg-white">
    <table class="w-full min-w-[32rem]">
      <thead class="bg-brand-surface"><tr><th class="th">Pesanan</th><th class="th">Customer</th><th class="th text-right">Total</th><th class="th">Status</th></tr></thead>
      <tbody class="divide-y divide-violet-100">
        <?php $__empty_1 = true; $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td class="td font-medium"><?php echo e($order->order_number); ?></td>
            <td class="td"><?php echo e($order->user->name); ?></td>
            <td class="td text-right"><?php echo e(\App\Support\Money::rp($order->total)); ?></td>
            <td class="td"><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['order' => $order]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['order' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td class="td text-center text-gray-500" colspan="4">Belum ada pesanan.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\tixora\tixora\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>