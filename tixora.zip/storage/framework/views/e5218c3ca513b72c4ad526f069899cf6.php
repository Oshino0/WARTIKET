<?php $__env->startSection('title', $product->name); ?>
<?php $__env->startSection('content'); ?>
  <?php $user = auth()->user(); ?>
  <div class="grid items-start gap-6 lg:grid-cols-[1fr_24rem]">
    <article>
      <?php if (isset($component)) { $__componentOriginal7ae9d3ce77f2d10c980f8a6b7578b79b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ae9d3ce77f2d10c980f8a6b7578b79b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cover','data' => ['item' => $product,'class' => 'rounded-2xl','ratio' => 'aspect-[16/9]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cover'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['item' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product),'class' => 'rounded-2xl','ratio' => 'aspect-[16/9]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ae9d3ce77f2d10c980f8a6b7578b79b)): ?>
<?php $attributes = $__attributesOriginal7ae9d3ce77f2d10c980f8a6b7578b79b; ?>
<?php unset($__attributesOriginal7ae9d3ce77f2d10c980f8a6b7578b79b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ae9d3ce77f2d10c980f8a6b7578b79b)): ?>
<?php $component = $__componentOriginal7ae9d3ce77f2d10c980f8a6b7578b79b; ?>
<?php unset($__componentOriginal7ae9d3ce77f2d10c980f8a6b7578b79b); ?>
<?php endif; ?>

      <p class="mt-5 text-sm font-medium text-brand">
        <a href="<?php echo e(route('explore', ['category' => $product->category->slug])); ?>"><?php echo e($product->category->name); ?></a>
      </p>
      <h1 class="mt-1 text-3xl font-extrabold tracking-tight"><?php echo e($product->name); ?></h1>

      <dl class="mt-4 grid gap-x-8 gap-y-2 text-sm sm:grid-cols-2">
        <div><dt class="text-gray-500">Jadwal</dt>
          <dd class="font-medium">
            <?php if($product->start_at): ?>
              <?php echo e($product->start_at->translatedFormat('l, d F Y • H:i')); ?>

              <?php if($product->end_at): ?> – <?php echo e($product->end_at->translatedFormat('H:i')); ?> <?php endif; ?>
            <?php else: ?> Jadwal menyusul <?php endif; ?>
          </dd></div>
        <?php if($product->location): ?>
          <div><dt class="text-gray-500">Lokasi</dt><dd class="font-medium"><?php echo e($product->location); ?></dd></div>
        <?php endif; ?>
      </dl>

    </article>

    <aside class="lg:sticky lg:top-6 lg:self-start">
      <div class="rounded-2xl border border-violet-100 p-5">
        <h2 class="text-lg font-bold">Pilih tiket</h2>

        <?php if($product->status !== \App\Models\Product::PUBLISHED): ?>
          <p class="mt-3 rounded-xl bg-gray-100 px-4 py-3 text-sm text-gray-600">Penjualan tiket untuk acara ini sudah ditutup.</p>
        <?php elseif($product->ticketTypes->isEmpty()): ?>
          <p class="mt-3 text-sm text-gray-500">Belum ada tipe tiket yang dijual.</p>
        <?php else: ?>
          <form action="<?php echo e(route('cart.store', $product->slug)); ?>" method="POST" id="ticket-form" class="mt-4">
            <?php echo csrf_field(); ?>
            <ul class="divide-y divide-violet-100">
              <?php $__currentLoopData = $product->ticketTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $left = $type->available();
                  $notOpen = $type->sale_start && $type->sale_start->isFuture();
                  $ended = $type->sale_end && $type->sale_end->isPast();
                  $disabled = $notOpen || $ended || $left === 0;
                  $max = min($type->max_per_order, $left);
                ?>
                <li class="py-4 first:pt-0">
                  <div class="flex items-start justify-between gap-3">
                    <div>
                      <p class="font-semibold"><?php echo e($type->name); ?></p>
                      <p class="text-sm font-bold text-brand"><?php echo e(\App\Support\Money::rp($type->price)); ?></p>
                      <p class="mt-1 text-xs text-gray-500">
                        <?php if($notOpen): ?> Dibuka <?php echo e($type->sale_start->translatedFormat('d M Y, H:i')); ?>

                        <?php elseif($ended): ?> Penjualan berakhir
                        <?php elseif($left === 0): ?> Habis
                        <?php else: ?>
                          Sisa <?php echo e($left); ?>

                          <?php if($type->min_per_order > 1): ?> • minimal <?php echo e($type->min_per_order); ?> <?php endif; ?>
                          • maks. <?php echo e($type->max_per_order); ?>/pesanan
                        <?php endif; ?>
                      </p>
                    </div>

                    <?php if(! $disabled): ?>
                      <div class="flex shrink-0 items-center gap-1" data-stepper data-price="<?php echo e((float) $type->price); ?>" data-min="<?php echo e($type->min_per_order); ?>">
                        <button type="button" class="btn btn-ghost !px-3 !py-1" data-dec aria-label="Kurangi <?php echo e($type->name); ?>">−</button>
                        <input type="number" name="items[<?php echo e($type->id); ?>]" value="0" min="0" max="<?php echo e($max); ?>"
                               class="w-12 rounded-lg border border-gray-300 py-1 text-center text-sm" aria-label="Jumlah <?php echo e($type->name); ?>">
                        <button type="button" class="btn btn-ghost !px-3 !py-1" data-inc aria-label="Tambah <?php echo e($type->name); ?>">+</button>
                      </div>
                    <?php endif; ?>
                  </div>
                </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <div class="mt-2 flex items-center justify-between border-t border-violet-100 pt-4 text-sm">
              <span class="text-gray-500">Perkiraan subtotal</span>
              <span id="subtotal" class="text-lg font-bold">Rp 0</span>
            </div>

            <?php if(! $user || $user->isCustomer()): ?>
              <button id="add-cart" class="btn btn-primary mt-4 w-full" disabled>Tambah ke keranjang</button>
              <p id="cart-selection-hint" class="mt-2 text-center text-xs text-gray-500">Pilih jumlah tiket yang ingin ditambahkan.</p>
            <?php else: ?>
              <p class="mt-4 rounded-xl bg-gray-100 px-4 py-3 text-sm text-gray-600">Akun admin dan petugas tidak dapat membeli tiket.</p>
            <?php endif; ?>
          </form>
        <?php endif; ?>
      </div>
    </aside>

    <?php if($product->description || ! empty($product->metadata)): ?>
      <section class="space-y-6 lg:col-span-2" aria-label="Detail acara">
        <?php if($product->description): ?>
          <div>
            <h2 class="text-lg font-bold">Tentang acara</h2>
            <p class="mt-2 max-w-prose whitespace-pre-line leading-relaxed text-gray-700"><?php echo e($product->description); ?></p>
          </div>
        <?php endif; ?>

        <?php if(! empty($product->metadata)): ?>
          <div>
            <h2 class="text-lg font-bold">Informasi tambahan</h2>
            <dl class="mt-2 max-w-prose divide-y divide-violet-100 rounded-2xl border border-violet-100 text-sm">
              <?php $__currentLoopData = $product->metadata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex justify-between gap-4 px-4 py-3"><dt class="text-gray-500"><?php echo e($key); ?></dt><dd class="text-right font-medium"><?php echo e($value); ?></dd></div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </dl>
          </div>
        <?php endif; ?>
      </section>
    <?php endif; ?>
  </div>

  <script>
    (function () {
      var form = document.getElementById('ticket-form');
      if (!form) return;
      var fmt = new Intl.NumberFormat('id-ID');
      var subtotal = document.getElementById('subtotal');
      var addCart = document.getElementById('add-cart');
      var hint = document.getElementById('cart-selection-hint');

      function refresh() {
        var sum = 0, count = 0, valid = true;
        form.querySelectorAll('[data-stepper]').forEach(function (s) {
          var qty = parseInt(s.querySelector('input').value, 10) || 0;
          var min = parseInt(s.dataset.min, 10) || 1;
          sum += qty * parseFloat(s.dataset.price);
          count += qty;
          if (qty > 0 && qty < min) valid = false;
        });
        subtotal.textContent = 'Rp ' + fmt.format(sum);
        if (addCart) addCart.disabled = count === 0 || !valid;
        if (hint) hint.textContent = !valid
          ? 'Jumlah tiket belum memenuhi minimum pembelian.'
          : count === 0
            ? 'Pilih jumlah tiket yang ingin ditambahkan.'
            : count + ' tiket dipilih. Stok belum dicadangkan sampai pesanan dibuat.';
      }

      form.querySelectorAll('[data-stepper]').forEach(function (s) {
        var input = s.querySelector('input');
        var max = parseInt(input.max, 10);
        s.querySelector('[data-inc]').addEventListener('click', function () {
          input.value = Math.min(max, (parseInt(input.value, 10) || 0) + 1); refresh();
        });
        s.querySelector('[data-dec]').addEventListener('click', function () {
          input.value = Math.max(0, (parseInt(input.value, 10) || 0) - 1); refresh();
        });
        input.addEventListener('input', refresh);
      });
      refresh();
    })();
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\tixora\tixora\resources\views\customer\product.blade.php ENDPATH**/ ?>