<?php $__env->startSection('title', 'Ubah tipe tiket'); ?>
<?php $__env->startSection('content'); ?>
  <a href="<?php echo e(route('admin.products.edit', $ticketType->product_id)); ?>" class="text-sm font-semibold text-brand">← <?php echo e($ticketType->product->name); ?></a>
  <h1 class="mt-2 text-2xl font-bold">Ubah tipe tiket</h1>
  <p class="mt-1 text-sm text-gray-500">Terjual <?php echo e($ticketType->sold); ?> • dicadangkan <?php echo e($ticketType->reserved); ?>. Pesanan lama tetap memakai harga saat dibeli.</p>

  <form action="<?php echo e(route('admin.ticket-types.update', $ticketType)); ?>" method="POST" class="mt-6 max-w-3xl space-y-4 rounded-2xl border border-violet-100 bg-white p-6">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <?php echo $__env->make('admin.ticket-types._fields', ['type' => $ticketType], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="flex gap-3">
      <button class="btn btn-primary">Simpan tipe tiket</button>
      <a href="<?php echo e(route('admin.products.edit', $ticketType->product_id)); ?>" class="btn btn-ghost">Batal</a>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\tixora\tixora\resources\views/admin/ticket-types/edit.blade.php ENDPATH**/ ?>