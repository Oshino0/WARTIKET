<h1>E-tiket TIXORA</h1>
<p>Halo <?php echo e($order->buyer_name); ?>, pesananmu sudah dikonfirmasi.</p>
<p>
  Nomor pesanan: <strong><?php echo e($order->order_number); ?></strong><br>
  Total: <strong><?php echo e(\App\Support\Money::rp($order->total)); ?></strong>
</p>

<?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <h2><?php echo e($item->product_name_snapshot); ?> — <?php echo e($item->ticket_type_name_snapshot); ?></h2>
  <?php if($item->ticketType?->product?->start_at): ?>
    <p>Jadwal: <?php echo e($item->ticketType->product->start_at->translatedFormat('d F Y, H:i')); ?></p>
  <?php endif; ?>
  <?php $__currentLoopData = $item->tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div style="margin: 16px 0; padding: 16px; border: 1px solid #ddd;">
      <p>Kode tiket: <strong><?php echo e($ticket->ticket_code); ?></strong></p>
      <img src="<?php echo e($message->embedData($qrCodes[$ticket->id], 'ticket-' . $ticket->id . '.svg', 'image/svg+xml')); ?>"
           width="180" height="180" alt="QR code <?php echo e($ticket->ticket_code); ?>">
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<p>Tunjukkan QR code tiket saat memasuki acara. Simpan email ini agar tiket mudah ditemukan.</p>
<?php /**PATH D:\project\tixora\tixora\resources\views/emails/orders/guest-tickets.blade.php ENDPATH**/ ?>