<?php $__env->startSection('title', 'Keranjang'); ?>
<?php $__env->startSection('content'); ?>
  <div class="mx-auto max-w-5xl">
    <div class="flex flex-wrap items-end justify-between gap-3">
      <div>
        <p class="text-sm font-semibold uppercase tracking-wide text-brand">Pilihan tiketmu</p>
        <h1 class="mt-1 text-3xl font-extrabold tracking-tight">Keranjang</h1>
      </div>
      <a href="<?php echo e(route('explore')); ?>" class="text-sm font-semibold text-brand hover:underline">Lanjut pilih tiket</a>
    </div>

    <?php if(empty($items)): ?>
      <div class="mt-6 rounded-2xl border border-dashed border-violet-200 bg-white px-6 py-14 text-center">
        <div class="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-brand-surface text-brand">
          <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" class="h-7 w-7">
            <path stroke-linecap="round" stroke-linejoin="round" d="M3 3h2l2.2 11.1a2 2 0 0 0 2 1.6h8.9a2 2 0 0 0 2-1.6L22 7H6" />
            <circle cx="10" cy="20" r="1" /><circle cx="18" cy="20" r="1" />
          </svg>
        </div>
        <h2 class="mt-4 text-lg font-bold">Keranjangmu masih kosong</h2>
        <p class="mt-1 text-sm text-gray-600">Pilih tiket dari acara yang ingin kamu datangi.</p>
        <a href="<?php echo e(route('explore')); ?>" class="btn btn-primary mt-5">Jelajahi tiket</a>
      </div>
    <?php else: ?>
      <?php if(! $canCheckout): ?>
        <div role="alert" class="mt-6 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
          Ada tiket yang jumlahnya perlu disesuaikan atau sudah tidak tersedia. Perbarui atau hapus tiket tersebut sebelum checkout.
        </div>
      <?php endif; ?>

      <div class="mt-6 grid items-start gap-6 lg:grid-cols-[1fr_20rem]">
        <section class="overflow-hidden rounded-2xl border border-violet-100 bg-white" aria-label="Isi keranjang">
          <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="border-b border-violet-100 p-5 last:border-b-0">
              <div class="flex flex-wrap items-start justify-between gap-4">
                <div class="min-w-0">
                  <?php if($item['product']): ?>
                    <a href="<?php echo e(route('products.show', $item['product'])); ?>" class="font-bold leading-snug hover:text-brand">
                      <?php echo e($item['product']->name); ?>

                    </a>
                  <?php else: ?>
                    <p class="font-bold">Acara tidak tersedia</p>
                  <?php endif; ?>
                  <p class="mt-1 text-sm text-gray-600"><?php echo e($item['type']?->name ?? 'Tipe tiket tidak tersedia'); ?></p>
                  <?php if($item['type']): ?>
                    <p class="mt-1 text-sm font-semibold text-brand"><?php echo e(\App\Support\Money::rp($item['type']->price)); ?> / tiket</p>
                  <?php endif; ?>
                  <?php if($item['issue']): ?>
                    <p class="mt-2 text-sm font-medium text-red-700"><?php echo e($item['issue']); ?></p>
                  <?php endif; ?>
                </div>

                <?php if($item['type']): ?>
                  <p class="whitespace-nowrap text-right text-sm font-bold">
                    <?php echo e(\App\Support\Money::rp((float) $item['type']->price * $item['quantity'])); ?>

                    <span class="block font-normal text-gray-500"><?php echo e($item['quantity']); ?> tiket</span>
                  </p>
                <?php endif; ?>
              </div>

              <div class="mt-4 flex flex-wrap items-center justify-between gap-3">
                <?php if($item['can_adjust']): ?>
                  <form action="<?php echo e(route('cart.update', $item['id'])); ?>" method="POST" class="flex items-center gap-2">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <label for="quantity-<?php echo e($item['id']); ?>" class="text-sm text-gray-600">Jumlah</label>
                    <input id="quantity-<?php echo e($item['id']); ?>" type="number" name="quantity" value="<?php echo e($item['quantity']); ?>"
                      min="<?php echo e($item['type']->min_per_order); ?>" max="<?php echo e(min($item['type']->max_per_order, $item['type']->available())); ?>"
                      class="w-20 rounded-lg border border-gray-300 px-2 py-1.5 text-sm focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30">
                    <button class="btn btn-ghost !px-3 !py-1.5">Perbarui</button>
                  </form>
                <?php endif; ?>

                <form action="<?php echo e(route('cart.destroy', $item['id'])); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="text-sm font-semibold text-red-700 hover:underline">Hapus</button>
                </form>
              </div>
            </article>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>

        <aside class="rounded-2xl border border-violet-100 bg-white p-5 lg:sticky lg:top-6">
          <h2 class="text-lg font-bold">Ringkasan</h2>
          <?php if($quote): ?>
            <div class="mt-4 flex justify-between gap-4 text-sm">
              <span class="text-gray-600">Subtotal tiket</span>
              <span class="font-semibold"><?php echo e(\App\Support\Money::rp($quote['subtotal'])); ?></span>
            </div>
            <?php if($quote['admin_fee'] > 0): ?>
              <div class="mt-2 flex justify-between gap-4 text-sm">
                <span class="text-gray-600">Biaya layanan</span>
                <span class="font-semibold"><?php echo e(\App\Support\Money::rp($quote['admin_fee'])); ?></span>
              </div>
            <?php endif; ?>
            <div class="mt-4 flex justify-between gap-4 border-t border-violet-100 pt-4 font-bold">
              <span>Total</span>
              <span class="text-brand"><?php echo e(\App\Support\Money::rp($quote['total'])); ?></span>
            </div>
            <p class="mt-3 text-xs leading-relaxed text-gray-500">Stok belum dicadangkan. Ketersediaan diperiksa kembali saat pesanan dibuat.</p>

            <a href="<?php echo e(route('checkout.review')); ?>" class="btn btn-primary mt-5 w-full">Lanjutkan tanpa akun</a>
            <p class="mt-2 text-center text-xs text-gray-500">Isi data pembeli untuk menyelesaikan pesanan.</p>
          <?php else: ?>
            <p class="mt-3 text-sm leading-relaxed text-gray-600">Total belum tersedia karena ada tiket yang tidak tersedia atau jumlahnya tidak valid.</p>
          <?php endif; ?>
        </aside>
      </div>
    <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\tixora\tixora\resources\views/customer/cart.blade.php ENDPATH**/ ?>