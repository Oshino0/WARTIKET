<?php $__env->startSection('title', 'Ringkasan pesanan'); ?>
<?php $__env->startSection('content'); ?>
  <div class="mx-auto max-w-2xl">
    <h1 class="text-2xl font-bold">Ringkasan pesanan</h1>
    <p class="mt-1 text-sm text-gray-500">Periksa pesananmu. Harga dan stok dihitung ulang saat kamu membuat pesanan.</p>

    <div class="mt-6 overflow-hidden rounded-2xl border border-violet-100">
      <table class="w-full">
        <thead class="bg-brand-surface"><tr><th class="th">Tiket</th><th class="th text-right">Jumlah</th><th class="th text-right">Subtotal</th></tr></thead>
        <tbody class="divide-y divide-violet-100">
          <?php $__currentLoopData = $quote['lines']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td class="td">
                <p class="font-semibold"><?php echo e($line['ticket_type']->product->name); ?></p>
                <p class="text-gray-500"><?php echo e($line['ticket_type']->name); ?> • <?php echo e(\App\Support\Money::rp($line['unit_price'])); ?></p>
              </td>
              <td class="td text-right"><?php echo e($line['quantity']); ?></td>
              <td class="td text-right"><?php echo e(\App\Support\Money::rp($line['line_total'])); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class="border-t border-violet-100 text-sm">
          <tr><td class="td text-gray-500" colspan="2">Subtotal</td><td class="td text-right"><?php echo e(\App\Support\Money::rp($quote['subtotal'])); ?></td></tr>
          <?php if($quote['admin_fee'] > 0): ?>
            <tr><td class="td text-gray-500" colspan="2">Biaya layanan</td><td class="td text-right"><?php echo e(\App\Support\Money::rp($quote['admin_fee'])); ?></td></tr>
          <?php endif; ?>
          <tr><td class="td text-base font-bold" colspan="2">Total</td><td class="td text-right text-base font-bold text-brand"><?php echo e(\App\Support\Money::rp($quote['total'])); ?></td></tr>
        </tfoot>
      </table>
    </div>

    <p class="mt-4 text-sm text-gray-600">Tiket dicadangkan untukmu selama <?php echo e($window); ?> menit setelah pesanan dibuat. Pesanan yang tidak dibayar dibatalkan otomatis.</p>

    <form action="<?php echo e(route('checkout.store')); ?>" method="POST" class="mt-6 flex flex-wrap gap-3" onsubmit="this.querySelector('button').disabled = true">
      <?php echo csrf_field(); ?>
      <?php $__currentLoopData = $quantities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $qty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <input type="hidden" name="items[<?php echo e($id); ?>]" value="<?php echo e($qty); ?>">
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <button class="btn btn-primary">Buat pesanan</button>
      <a href="<?php echo e(route('cart.index')); ?>" class="btn btn-ghost">Kembali ke keranjang</a>
    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\tixora\tixora\resources\views\customer\checkout.blade.php ENDPATH**/ ?>