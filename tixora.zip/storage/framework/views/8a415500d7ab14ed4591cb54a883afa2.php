<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['product']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['product']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
  $active = $product->ticketTypes->where('status', 'active');
  $soldOut = $active->isNotEmpty() && $active->sum(fn ($t) => $t->available()) === 0;
  $closed = $product->status !== \App\Models\Product::PUBLISHED;
?>
<a href="<?php echo e(route('products.show', $product)); ?>"
   class="group block overflow-hidden rounded-2xl border border-violet-100 bg-white transition hover:border-brand-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand">
  <?php if (isset($component)) { $__componentOriginal7ae9d3ce77f2d10c980f8a6b7578b79b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ae9d3ce77f2d10c980f8a6b7578b79b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cover','data' => ['item' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cover'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['item' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ae9d3ce77f2d10c980f8a6b7578b79b)): ?>
<?php $attributes = $__attributesOriginal7ae9d3ce77f2d10c980f8a6b7578b79b; ?>
<?php unset($__attributesOriginal7ae9d3ce77f2d10c980f8a6b7578b79b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ae9d3ce77f2d10c980f8a6b7578b79b)): ?>
<?php $component = $__componentOriginal7ae9d3ce77f2d10c980f8a6b7578b79b; ?>
<?php unset($__componentOriginal7ae9d3ce77f2d10c980f8a6b7578b79b); ?>
<?php endif; ?>
  <div class="perf"></div>
  <div class="p-4 pt-3">
    <p class="text-xs font-medium text-brand"><?php echo e($product->category->name); ?></p>
    <h3 class="mt-1 line-clamp-2 font-semibold leading-snug"><?php echo e($product->name); ?></h3>
    <p class="mt-2 text-sm text-gray-500">
      <?php echo e($product->start_at?->translatedFormat('d M Y') ?? 'Jadwal menyusul'); ?>

      <?php if($product->location): ?> • <?php echo e($product->location); ?> <?php endif; ?>
    </p>
    <p class="mt-3 text-sm">
      <?php if($closed): ?>
        <span class="font-semibold text-gray-500">Penjualan ditutup</span>
      <?php elseif($soldOut): ?>
        <span class="font-semibold text-red-700">Habis</span>
      <?php elseif($product->starting_price !== null): ?>
        <span class="text-gray-500">Mulai</span> <span class="font-bold"><?php echo e(\App\Support\Money::rp($product->starting_price)); ?></span>
      <?php endif; ?>
    </p>
  </div>
</a>
<?php /**PATH D:\project\tixora\tixora\resources\views/components/product-card.blade.php ENDPATH**/ ?>