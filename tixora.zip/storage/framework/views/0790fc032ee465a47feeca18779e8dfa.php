<?php $__env->startSection('title', $product->exists ? 'Kelola produk' : 'Tambah produk'); ?>
<?php $__env->startSection('content'); ?>
  <?php
    $keys = old('meta_keys');
    $vals = old('meta_values');
    $rows = $keys !== null
      ? collect($keys)->map(fn ($k, $i) => [$k, $vals[$i] ?? ''])->values()->all()
      : collect($product->metadata ?? [])->map(fn ($v, $k) => [$k, $v])->values()->all();
    $dt = fn ($d) => $d?->format('Y-m-d\TH:i');
  ?>

  <h1 class="text-2xl font-bold"><?php echo e($product->exists ? $product->name : 'Tambah produk'); ?></h1>

  <form action="<?php echo e($product->exists ? route('admin.products.update', $product) : route('admin.products.store')); ?>"
        method="POST" enctype="multipart/form-data" class="mt-6 max-w-3xl space-y-8 rounded-2xl border border-violet-100 bg-white p-6">
    <?php echo csrf_field(); ?>
    <?php if($product->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    <section class="space-y-4">
      <h2 class="font-bold">Informasi umum</h2>
      <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['label' => 'Nama produk','name' => 'name','value' => $product->name,'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Nama produk','name' => 'name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->name),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>

      <div>
        <label for="category_id" class="mb-1 block text-sm font-medium">Kategori</label>
        <select id="category_id" name="category_id" class="input" required>
          <option value="">Pilih kategori</option>
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>" <?php if((int) old('category_id', $product->category_id) === $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php if($categories->isEmpty()): ?><p class="mt-1 text-sm text-amber-700">Buat kategori dulu di menu Kategori.</p><?php endif; ?>
      </div>

      <div>
        <label for="description" class="mb-1 block text-sm font-medium">Deskripsi</label>
        <textarea id="description" name="description" rows="5" class="input"><?php echo e(old('description', $product->description)); ?></textarea>
        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div>
        <?php if($product->image_url): ?><img src="<?php echo e($product->image_url); ?>" alt="" class="mb-2 h-24 rounded-xl object-cover"><?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['label' => 'Gambar utama','name' => 'image','type' => 'file','accept' => 'image/*','hint' => 'JPG atau PNG, maksimal 2 MB.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Gambar utama','name' => 'image','type' => 'file','accept' => 'image/*','hint' => 'JPG atau PNG, maksimal 2 MB.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
      </div>

      <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['label' => 'Lokasi atau venue','name' => 'location','value' => $product->location]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Lokasi atau venue','name' => 'location','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->location)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
    </section>

    <section class="space-y-4">
      <h2 class="font-bold">Jadwal</h2>
      <div class="grid gap-4 sm:grid-cols-2">
        <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['label' => 'Mulai','name' => 'start_at','type' => 'datetime-local','value' => $dt($product->start_at)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Mulai','name' => 'start_at','type' => 'datetime-local','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dt($product->start_at))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['label' => 'Selesai','name' => 'end_at','type' => 'datetime-local','value' => $dt($product->end_at)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Selesai','name' => 'end_at','type' => 'datetime-local','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dt($product->end_at))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
      </div>
    </section>

    <section>
      <h2 class="font-bold">Atribut tambahan</h2>
      <p class="mt-1 text-sm text-gray-500">Isi sesuai jenis produk, misalnya "Nama artis", "Tribun", "Studio", atau "Pembicara". Tampil di halaman detail.</p>
      <div id="meta-rows" class="mt-3 space-y-2">
        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$k, $v]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="flex gap-2">
            <input name="meta_keys[]" value="<?php echo e($k); ?>" placeholder="Nama atribut" class="input" aria-label="Nama atribut">
            <input name="meta_values[]" value="<?php echo e($v); ?>" placeholder="Nilai" class="input" aria-label="Nilai atribut">
            <button type="button" class="btn btn-ghost" data-remove>Hapus</button>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <button type="button" id="add-meta" class="btn btn-ghost mt-3">Tambah atribut</button>
    </section>

    <section class="space-y-4">
      <h2 class="font-bold">Publikasi</h2>
      <?php if($product->exists): ?>
        <div>
          <label for="status" class="mb-1 block text-sm font-medium">Status</label>
          <select id="status" name="status" class="input max-w-xs">
            <?php $__currentLoopData = \App\Models\Product::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($value); ?>" <?php if(old('status', $product->status) === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      <?php else: ?>
        <p class="text-sm text-gray-500">Produk baru disimpan sebagai draft. Setelah menambahkan tipe tiket, kamu bisa mempublikasikannya.</p>
      <?php endif; ?>
      <label class="flex items-center gap-2 text-sm">
        <input type="hidden" name="is_featured" value="0">
        <input type="checkbox" name="is_featured" value="1" class="rounded border-gray-300 text-brand focus:ring-brand" <?php if(old('is_featured', $product->is_featured)): echo 'checked'; endif; ?>>
        Tampilkan di "Tiket populer" pada homepage
      </label>
    </section>

    <div class="flex gap-3">
      <button class="btn btn-primary"><?php echo e($product->exists ? 'Simpan perubahan' : 'Simpan sebagai draft'); ?></button>
      <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-ghost">Kembali</a>
    </div>
  </form>

  <?php if($product->exists): ?>
    <section class="mt-10 max-w-5xl">
      <h2 class="text-lg font-bold">Tipe tiket</h2>

      <div class="mt-3 overflow-x-auto rounded-2xl border border-violet-100 bg-white">
        <table class="w-full min-w-[44rem]">
          <thead class="bg-brand-surface"><tr>
            <th class="th">Tipe</th><th class="th text-right">Harga</th><th class="th text-right">Terjual / dicadangkan / kuota</th>
            <th class="th text-right">Per pesanan</th><th class="th">Periode jual</th><th class="th">Status</th><th class="th"></th>
          </tr></thead>
          <tbody class="divide-y divide-violet-100">
            <?php $__empty_1 = true; $__currentLoopData = $product->ticketTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td class="td font-medium"><?php echo e($type->name); ?></td>
                <td class="td text-right"><?php echo e(\App\Support\Money::rp($type->price)); ?></td>
                <td class="td text-right"><?php echo e($type->sold); ?> / <?php echo e($type->reserved); ?> / <?php echo e($type->quota); ?></td>
                <td class="td text-right"><?php echo e($type->min_per_order); ?>–<?php echo e($type->max_per_order); ?></td>
                <td class="td text-gray-500">
                  <?php echo e($type->sale_start?->translatedFormat('d M Y H:i') ?? 'Langsung'); ?> → <?php echo e($type->sale_end?->translatedFormat('d M Y H:i') ?? 'Tanpa batas'); ?>

                </td>
                <td class="td"><?php echo e($type->status === 'active' ? 'Aktif' : 'Nonaktif'); ?></td>
                <td class="td">
                  <div class="flex justify-end gap-2">
                    <a href="<?php echo e(route('admin.ticket-types.edit', $type)); ?>" class="btn btn-ghost !py-1">Ubah</a>
                    <form action="<?php echo e(route('admin.ticket-types.destroy', $type)); ?>" method="POST" onsubmit="return confirm('Hapus tipe tiket <?php echo e(addslashes($type->name)); ?>?')">
                      <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                      <button class="btn btn-danger !py-1">Hapus</button>
                    </form>
                  </div>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr><td class="td text-center text-gray-500" colspan="7">Belum ada tipe tiket. Tambahkan di bawah.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <form action="<?php echo e(route('admin.ticket-types.store', $product)); ?>" method="POST" class="mt-6 max-w-3xl space-y-4 rounded-2xl border border-violet-100 bg-white p-6">
        <?php echo csrf_field(); ?>
        <h3 class="font-bold">Tambah tipe tiket</h3>
        <?php echo $__env->make('admin.ticket-types._fields', ['type' => new \App\Models\TicketType(['min_per_order' => 1, 'max_per_order' => 10, 'status' => 'active'])], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <button class="btn btn-primary">Tambah tipe tiket</button>
      </form>
    </section>
  <?php endif; ?>

  <script>
    (function () {
      var rows = document.getElementById('meta-rows');
      document.getElementById('add-meta').addEventListener('click', function () {
        var d = document.createElement('div');
        d.className = 'flex gap-2';
        d.innerHTML = '<input name="meta_keys[]" placeholder="Nama atribut" class="input" aria-label="Nama atribut">' +
          '<input name="meta_values[]" placeholder="Nilai" class="input" aria-label="Nilai atribut">' +
          '<button type="button" class="btn btn-ghost" data-remove>Hapus</button>';
        rows.appendChild(d);
        d.querySelector('input').focus();
      });
      rows.addEventListener('click', function (e) {
        if (e.target.matches('[data-remove]')) e.target.closest('div').remove();
      });
    })();
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\tixora\tixora\resources\views/admin/products/form.blade.php ENDPATH**/ ?>