<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['order']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['order']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
  $style = match ($order->status) {
    'pending', 'pending_verification' => 'bg-amber-50 text-amber-800 border-amber-200',
    'paid', 'sent' => 'bg-emerald-50 text-emerald-800 border-emerald-200',
    'refunded' => 'bg-sky-50 text-sky-800 border-sky-200',
    'rejected' => 'bg-red-50 text-red-800 border-red-200',
    default => 'bg-gray-100 text-gray-700 border-gray-200',
  };
?>
<span class="inline-flex rounded-full border px-2.5 py-0.5 text-xs font-semibold <?php echo e($style); ?>"><?php echo e($order->label()); ?></span>
<?php /**PATH D:\project\tixora\tixora\resources\views/components/status-badge.blade.php ENDPATH**/ ?>