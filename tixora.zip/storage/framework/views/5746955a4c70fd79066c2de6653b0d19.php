<?php $__env->startSection('title', 'Pesanan ' . $order->order_number); ?>
<?php $__env->startSection('content'); ?>
  <?php
    $checking = request()->boolean('checking') && $order->isPending();
    $paidPayment = $order->payments->firstWhere('status', 'paid');
  ?>

  <div class="mx-auto max-w-2xl">
    <a href="<?php echo e(route('orders.index')); ?>" class="text-sm font-semibold text-brand">← Semua pesanan</a>

    <div class="mt-3 flex flex-wrap items-center justify-between gap-3">
      <h1 class="text-2xl font-bold"><?php echo e($order->order_number); ?></h1>
      <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['order' => $order]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['order' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
    </div>
    <p class="mt-1 text-sm text-gray-500">Dibuat <?php echo e($order->created_at->translatedFormat('d F Y, H:i')); ?></p>

    <?php if($order->status === 'paid'): ?>
      <div class="mt-5 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-900">
        Pembayaran diterima. <?php if($paidPayment?->payment_method): ?> Metode: <strong><?php echo e($paidPayment->payment_method); ?></strong>. <?php endif; ?>
        E-ticket akan muncul di halaman ini.
      </div>
    <?php elseif($checking): ?>
      <div role="status" class="mt-5 rounded-2xl border border-violet-200 bg-brand-surface p-4 text-sm text-brand">
        Kami sedang memastikan pembayaranmu ke iPaymu. Halaman ini diperbarui otomatis, biasanya hanya beberapa detik.
      </div>
      <script>setTimeout(function () { location.reload(); }, 8000);</script>
    <?php elseif($order->isPending()): ?>
      <div class="mt-5 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
        Tiketmu dicadangkan sampai <strong><?php echo e($order->expires_at->translatedFormat('d F Y, H:i')); ?></strong>.
        Setelah itu pesanan dibatalkan otomatis dan tiket dikembalikan ke penjualan.
      </div>
    <?php endif; ?>

    <div class="mt-6 overflow-hidden rounded-2xl border border-violet-100">
      <table class="w-full">
        <thead class="bg-brand-surface"><tr><th class="th">Tiket</th><th class="th text-right">Jumlah</th><th class="th text-right">Subtotal</th></tr></thead>
        <tbody class="divide-y divide-violet-100">
          <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td class="td"><p class="font-semibold"><?php echo e($item->product_name_snapshot); ?></p>
                <p class="text-gray-500"><?php echo e($item->ticket_type_name_snapshot); ?> • <?php echo e(\App\Support\Money::rp($item->unit_price)); ?></p></td>
              <td class="td text-right"><?php echo e($item->quantity); ?></td>
              <td class="td text-right"><?php echo e(\App\Support\Money::rp($item->line_total)); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class="border-t border-violet-100">
          <tr><td class="td text-gray-500" colspan="2">Subtotal</td><td class="td text-right"><?php echo e(\App\Support\Money::rp($order->subtotal)); ?></td></tr>
          <?php if($order->admin_fee > 0): ?>
            <tr><td class="td text-gray-500" colspan="2">Biaya layanan</td><td class="td text-right"><?php echo e(\App\Support\Money::rp($order->admin_fee)); ?></td></tr>
          <?php endif; ?>
          <tr><td class="td text-base font-bold" colspan="2">Total</td><td class="td text-right text-base font-bold text-brand"><?php echo e(\App\Support\Money::rp($order->total)); ?></td></tr>
        </tfoot>
      </table>
    </div>

    <?php if($order->isPending()): ?>
      <div class="mt-6 flex flex-wrap gap-3">
        <form action="<?php echo e(route('orders.pay', $order->order_number)); ?>" method="POST" onsubmit="this.querySelector('button').disabled = true">
          <?php echo csrf_field(); ?>
          <button class="btn btn-primary">Bayar sekarang</button>
        </form>
        <form action="<?php echo e(route('orders.cancel', $order->order_number)); ?>" method="POST" onsubmit="return confirm('Batalkan pesanan ini?')">
          <?php echo csrf_field(); ?>
          <button class="btn btn-danger">Batalkan pesanan</button>
        </form>
      </div>
      <p class="mt-2 text-xs text-gray-500">Kamu akan diarahkan ke halaman pembayaran iPaymu (VA, QRIS, e-wallet, dan lainnya).</p>
    <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\tixora\tixora\resources\views\customer\orders\show.blade.php ENDPATH**/ ?>