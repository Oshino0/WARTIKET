<?php $__env->startSection('title', 'Pembayaran'); ?>
<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-bold">Pembayaran</h1>

  <form method="GET" class="mt-6 flex flex-wrap items-center gap-3">
    <label for="status" class="sr-only">Status</label>
    <select id="status" name="status" class="input max-w-[14rem]">
      <option value="">Semua status</option>
      <?php $__currentLoopData = \App\Models\Payment::LABELS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($value); ?>" <?php if(request('status') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <label class="flex items-center gap-2 text-sm">
      <input type="checkbox" name="review" value="1" class="rounded border-gray-300 text-brand focus:ring-brand" <?php if(request()->boolean('review')): echo 'checked'; endif; ?>>
      Hanya yang perlu ditinjau
    </label>
    <button class="btn btn-ghost">Filter</button>
  </form>

  <div class="mt-4 overflow-x-auto rounded-2xl border border-violet-100 bg-white">
    <table class="w-full min-w-[52rem]">
      <thead class="bg-brand-surface"><tr>
        <th class="th">Referensi</th><th class="th">Customer</th><th class="th text-right">Jumlah</th>
        <th class="th">Metode</th><th class="th">Status</th><th class="th">Dibayar</th><th class="th">Catatan</th>
      </tr></thead>
      <tbody class="divide-y divide-violet-100">
        <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr class="<?php echo e($payment->needs_review ? 'bg-amber-50' : ''); ?>">
            <td class="td font-medium"><?php echo e($payment->reference_id); ?><br>
              <span class="text-xs font-normal text-gray-500">iPaymu #<?php echo e($payment->transaction_id ?? '–'); ?> • pesanan <?php echo e($payment->order->status); ?></span></td>
            <td class="td"><?php echo e($payment->order->user->name); ?></td>
            <td class="td text-right"><?php echo e(\App\Support\Money::rp($payment->amount)); ?></td>
            <td class="td"><?php echo e($payment->payment_method ?? '–'); ?></td>
            <td class="td"><?php echo e($payment->label()); ?></td>
            <td class="td text-gray-500"><?php echo e($payment->paid_at?->translatedFormat('d M Y, H:i') ?? '–'); ?></td>
            <td class="td text-amber-900"><?php echo e($payment->review_note); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td class="td text-center text-gray-500" colspan="7">Belum ada pembayaran.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <div class="mt-4"><?php echo e($payments->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\tixora\tixora\resources\views/admin/payments/index.blade.php ENDPATH**/ ?>