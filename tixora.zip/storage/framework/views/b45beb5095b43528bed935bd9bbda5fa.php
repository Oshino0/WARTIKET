<?php $__env->startSection('title', 'Kategori'); ?>
<?php $__env->startSection('content'); ?>
  <div class="flex items-center justify-between">
    <h1 class="text-2xl font-bold">Kategori</h1>
    <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-primary">Tambah kategori</a>
  </div>

  <div class="mt-6 overflow-x-auto rounded-2xl border border-violet-100 bg-white">
    <table class="w-full min-w-[32rem]">
      <thead class="bg-brand-surface"><tr><th class="th">Nama</th><th class="th">Slug</th><th class="th text-right">Produk</th><th class="th">Status</th><th class="th"></th></tr></thead>
      <tbody class="divide-y divide-violet-100">
        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td class="td font-medium"><?php echo e($category->name); ?></td>
            <td class="td text-gray-500"><?php echo e($category->slug); ?></td>
            <td class="td text-right"><?php echo e($category->products_count); ?></td>
            <td class="td"><?php echo e($category->is_active ? 'Aktif' : 'Nonaktif'); ?></td>
            <td class="td">
              <div class="flex justify-end gap-2">
                <a href="<?php echo e(route('admin.categories.edit', $category)); ?>" class="btn btn-ghost !py-1">Ubah</a>
                <form action="<?php echo e(route('admin.categories.destroy', $category)); ?>" method="POST" onsubmit="return confirm('Hapus kategori <?php echo e(addslashes($category->name)); ?>?')">
                  <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-danger !py-1">Hapus</button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td class="td text-center text-gray-500" colspan="5">Belum ada kategori. Tambahkan kategori pertama untuk mulai membuat produk.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <div class="mt-4"><?php echo e($categories->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\tixora\tixora\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>