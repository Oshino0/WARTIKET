<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['item', 'ratio' => 'aspect-[16/10]']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['item', 'ratio' => 'aspect-[16/10]']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div <?php echo e($attributes->merge(['class' => 'overflow-hidden bg-brand-surface ' . $ratio])); ?>>
  <?php if($item->image_url): ?>
    <img src="<?php echo e($item->image_url); ?>" alt="<?php echo e($item->name); ?>" class="h-full w-full object-cover" loading="lazy">
  <?php else: ?>
    <div class="flex h-full w-full items-center justify-center bg-brand" aria-hidden="true">
      <span class="text-5xl font-extrabold text-white/90"><?php echo e(mb_strtoupper(mb_substr($item->name, 0, 1))); ?></span>
    </div>
  <?php endif; ?>
</div>
<?php /**PATH D:\project\tixora\tixora\resources\views\components\cover.blade.php ENDPATH**/ ?>