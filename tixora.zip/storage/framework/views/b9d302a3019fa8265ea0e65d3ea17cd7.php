<?php $__env->startSection('title', 'Jelajahi tiket'); ?>
<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-bold">Jelajahi tiket</h1>

  <form action="<?php echo e(route('explore')); ?>" method="GET" aria-label="Filter tiket" class="mt-3 flex flex-col items-start gap-3 sm:flex-row sm:items-end">
    <?php if($search !== ''): ?> <input type="hidden" name="q" value="<?php echo e($search); ?>"> <?php endif; ?>
    <div class="w-full sm:max-w-xs">
      <label for="category" class="mb-1 block text-sm font-medium text-gray-700">Kategori acara</label>
      <select id="category" name="category" class="input">
        <option value="">Semua kategori</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($category->slug); ?>" <?php if($activeCategory === $category->slug): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <button class="btn btn-primary">Filter</button>
    <?php if($activeCategory): ?>
      <a href="<?php echo e(route('explore', $search !== '' ? ['q' => $search] : [])); ?>" class="btn btn-ghost">Hapus filter</a>
    <?php endif; ?>
  </form>

  <?php if($products->isEmpty()): ?>
    <p class="mt-8 rounded-2xl border border-dashed border-violet-200 p-10 text-center text-gray-500">
      Tidak ada tiket yang cocok. Coba kata kunci lain di pencarian atas atau pilih kategori lain.
    </p>
  <?php else: ?>
    <div class="mt-5 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if (isset($component)) { $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-card','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $attributes = $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $component = $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="mt-8"><?php echo e($products->links()); ?></div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\tixora\tixora\resources\views/customer/explore.blade.php ENDPATH**/ ?>