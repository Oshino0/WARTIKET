<?php $__env->startSection('title', 'Pesanan ' . $order->order_number); ?>
<?php $__env->startSection('content'); ?>
  <div class="mx-auto max-w-4xl">
    <a href="<?php echo e(route('admin.orders.index')); ?>" class="text-sm font-semibold text-brand">← Kembali ke pesanan</a>

    <div class="mt-4 flex flex-wrap items-start justify-between gap-4">
      <div>
        <h1 class="text-2xl font-bold"><?php echo e($order->order_number); ?></h1>
        <p class="mt-1 text-sm text-gray-500">Dibuat <?php echo e($order->created_at->translatedFormat('d F Y, H:i')); ?></p>
      </div>
      <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['order' => $order]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['order' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
    </div>

    <section class="mt-6 rounded-2xl border border-violet-100 bg-white p-5">
      <h2 class="font-bold">Data pembeli</h2>
      <dl class="mt-3 grid gap-3 text-sm sm:grid-cols-2">
        <div><dt class="text-gray-500">Nama</dt><dd class="font-medium"><?php echo e($order->buyer_name ?? $order->user?->name); ?></dd></div>
        <div><dt class="text-gray-500">Email</dt><dd class="font-medium"><?php echo e($order->buyer_email ?? $order->user?->email); ?></dd></div>
        <div><dt class="text-gray-500">WhatsApp</dt><dd class="font-medium"><?php echo e($order->buyer_phone ?? $order->user?->phone ?? '—'); ?></dd></div>
      </dl>
    </section>

    <section class="mt-5 overflow-hidden rounded-2xl border border-violet-100 bg-white">
      <h2 class="px-5 pt-5 font-bold">Detail tiket</h2>
      <div class="mt-3 divide-y divide-violet-100">
        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="flex flex-wrap justify-between gap-3 px-5 py-4">
            <div>
              <p class="font-semibold"><?php echo e($item->product_name_snapshot); ?></p>
              <p class="text-sm text-gray-500"><?php echo e($item->ticket_type_name_snapshot); ?> × <?php echo e($item->quantity); ?></p>
              <p class="mt-1 text-xs text-gray-500">Harga satuan <?php echo e(\App\Support\Money::rp($item->unit_price)); ?></p>
            </div>
            <p class="font-semibold"><?php echo e(\App\Support\Money::rp($item->line_total)); ?></p>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="flex justify-between border-t border-violet-100 px-5 py-4 font-bold">
        <span>Total</span>
        <span><?php echo e(\App\Support\Money::rp($order->total)); ?></span>
      </div>
    </section>

    <?php if($order->status === \App\Models\Order::PENDING_VERIFICATION): ?>
      <div class="mt-5 flex flex-wrap gap-3">
        <form action="<?php echo e(route('admin.orders.verify', $order)); ?>" method="POST"
              onsubmit="return confirm('Konfirmasi pesanan dan kirim e-tiket ke <?php echo e(addslashes($order->buyer_email)); ?>?')">
          <?php echo csrf_field(); ?>
          <button class="btn btn-primary">Konfirmasi &amp; kirim tiket</button>
        </form>
        <form action="<?php echo e(route('admin.orders.reject', $order)); ?>" method="POST"
              onsubmit="return confirm('Tolak pesanan ini dan kembalikan stok tiket?')">
          <?php echo csrf_field(); ?>
          <button class="btn btn-danger">Tolak pesanan</button>
        </form>
      </div>
    <?php elseif($order->status === \App\Models\Order::SENT): ?>
      <section class="mt-5 rounded-2xl border border-emerald-200 bg-emerald-50 p-5">
        <h2 class="font-bold text-emerald-900">Tiket telah dikirim</h2>
        <ul class="mt-3 space-y-2 text-sm text-emerald-900">
          <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $item->tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($ticket->ticket_code); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php if($order->buyer_email): ?>
          <form class="mt-4" action="<?php echo e(route('admin.orders.resend', $order)); ?>" method="POST"
                onsubmit="return confirm('Kirim ulang e-tiket ke <?php echo e(addslashes($order->buyer_email)); ?>?')">
            <?php echo csrf_field(); ?>
            <button class="btn btn-primary">Kirim ulang e-tiket</button>
          </form>
        <?php endif; ?>
      </section>
    <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\tixora\tixora\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>