<h1>E-tiket TIXORA</h1>
<p>Halo {{ $order->buyer_name }}, pesananmu sudah dikonfirmasi.</p>
<p>
  Nomor pesanan: <strong>{{ $order->order_number }}</strong><br>
  Total: <strong>{{ \App\Support\Money::rp($order->total) }}</strong>
</p>

@foreach ($order->items as $item)
  <h2>{{ $item->product_name_snapshot }} — {{ $item->ticket_type_name_snapshot }}</h2>
  @if ($item->ticketType?->product?->start_at)
    <p>Jadwal: {{ $item->ticketType->product->start_at->translatedFormat('d F Y, H:i') }}</p>
  @endif
  @foreach ($item->tickets as $ticket)
    <div style="margin: 16px 0; padding: 16px; border: 1px solid #ddd;">
      <p>Kode tiket: <strong>{{ $ticket->ticket_code }}</strong></p>
      <img src="{{ $message->embedData($qrCodes[$ticket->id], 'ticket-' . $ticket->id . '.svg', 'image/svg+xml') }}"
           width="180" height="180" alt="QR code {{ $ticket->ticket_code }}">
    </div>
  @endforeach
@endforeach

<p>Tunjukkan QR code tiket saat memasuki acara. Simpan email ini agar tiket mudah ditemukan.</p>
