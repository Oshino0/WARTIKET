<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Services\OrderService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class CheckoutController extends Controller
{
    public function __construct(private OrderService $orders) {}

    /** Step 1: show a server-calculated summary of what the customer picked. */
    public function review(Request $request): View|RedirectResponse
    {
        $quantities = $this->cartQuantities($request);

        if ($quantities === []) {
            return redirect()->route('cart.index')->with('status', 'Keranjang masih kosong. Pilih tiket sebelum checkout.');
        }

        $quote = $this->orders->quote($quantities);

        return view('customer.checkout', [
            'quote' => $quote,
            'quantities' => $quantities,
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'buyer_name' => ['required', 'string', 'min:3', 'max:100'],
            'buyer_email' => ['required', 'email', 'max:150'],
            'buyer_phone' => [
                'required',
                'string',
                'max:30',
                'regex:/^\+?[0-9][0-9\s().-]{7,29}$/',
                function (string $attribute, string $value, \Closure $fail): void {
                    $digits = preg_replace('/\D/', '', $value);
                    if (strlen($digits) < 8 || strlen($digits) > 15) {
                        $fail('Nomor WhatsApp harus berisi 8 sampai 15 digit.');
                    }
                },
            ],
            'items' => ['required', 'array'],
            'items.*' => ['nullable', 'integer', 'min:0', 'max:100'],
        ]);

        $quantities = $this->cartQuantities($request);
        $submitted = collect($data['items'])
            ->map(fn ($quantity) => (int) $quantity)
            ->filter(fn ($quantity) => $quantity > 0)
            ->sortKeys()
            ->all();

        if ($quantities === [] || $submitted !== $quantities) {
            return redirect()->route('cart.index')->with('status', 'Keranjang berubah. Periksa kembali tiket sebelum membuat pesanan.');
        }

        $order = $this->orders->createGuest(
            $data['buyer_name'],
            $data['buyer_email'],
            $data['buyer_phone'],
            $quantities,
        );
        $request->session()->forget('cart');
        $request->session()->put('guest_order_number', $order->order_number);

        return redirect()
            ->route('checkout.confirmation', $order->order_number);
    }

    public function confirmation(Request $request, string $orderNumber): View
    {
        abort_unless($request->session()->get('guest_order_number') === $orderNumber, 404);

        $order = Order::with(['items.tickets'])
            ->where('order_number', $orderNumber)
            ->firstOrFail();

        return view('customer.checkout-confirmation', compact('order'));
    }

    private function cartQuantities(Request $request): array
    {
        return collect($request->session()->get('cart', []))
            ->map(fn ($quantity) => (int) $quantity)
            ->filter(fn ($quantity) => $quantity > 0)
            ->sortKeys()
            ->all();
    }
}
