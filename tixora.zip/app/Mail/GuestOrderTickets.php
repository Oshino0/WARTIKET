<?php

namespace App\Mail;

use App\Models\Order;
use Endroid\QrCode\Builder\Builder;
use Endroid\QrCode\Writer\SvgWriter;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class GuestOrderTickets extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(public Order $order)
    {
        $this->order->loadMissing(['items.tickets', 'items.ticketType.product']);
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'E-tiket pesanan '.$this->order->order_number,
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.orders.guest-tickets',
            with: ['qrCodes' => $this->qrCodes()],
        );
    }

    private function qrCodes(): array
    {
        $qrCodes = [];

        foreach ($this->order->items as $item) {
            foreach ($item->tickets as $ticket) {
                $qrCodes[$ticket->id] = Builder::create()
                    ->writer(new SvgWriter)
                    ->data($ticket->qr_token)
                    ->size(240)
                    ->margin(12)
                    ->build()
                    ->getString();
            }
        }

        return $qrCodes;
    }
}
